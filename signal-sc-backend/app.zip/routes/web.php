<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminPanelController;
use App\Http\Controllers\IbPartnerPageController;
use App\Http\Controllers\CsvAnalyticsController;
use App\Http\Controllers\IbPartnerManageController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\TradeManageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminCommunityController;
use App\Http\Controllers\AdminNewsController;
use App\Http\Controllers\AdminChatController;
use App\Http\Controllers\AdminFeedController;
use App\Http\Controllers\DatabaseBackupController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn() => redirect()->route('login'));

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware('auth')->group(function () {
    // Dashboard & Admin Panel
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/admin/panel', [AdminPanelController::class, 'index'])->name('admin.panel');

    // Trade CRUD
    Route::post('/admin/trades', [TradeManageController::class, 'store'])->name('admin.trades.store');
    Route::post('/admin/trades/import', [TradeManageController::class, 'import'])->name('admin.trades.import');
    Route::put('/admin/trades/{trade}', [TradeManageController::class, 'update'])->name('admin.trades.update');
    Route::delete('/admin/trades/{trade}', [TradeManageController::class, 'destroy'])->name('admin.trades.destroy');

    // IB Partners
    Route::get('/admin/ib-partners', [IbPartnerPageController::class, 'index'])->name('admin.ib-partners');
    Route::post('/admin/ib/member', [IbPartnerManageController::class, 'storeMember'])->name('admin.ib.member.store');
    Route::post('/admin/ib/partner', [IbPartnerManageController::class, 'storePartner'])->name('admin.ib.partner.store');
    Route::get('/admin/ib/search', [IbPartnerManageController::class, 'search'])->name('admin.ib.search');
    Route::get('/admin/ib/sync', [IbPartnerManageController::class, 'syncMembers'])->name('admin.ib.sync');

    // CSV Analytics
    Route::get('/admin/csv-analytics', [CsvAnalyticsController::class, 'index'])->name('admin.csv-analytics');
    Route::post('/admin/csv-analytics/auto-create-members', [CsvAnalyticsController::class, 'autoCreateMembers'])->name('admin.csv-analytics.auto-create');

    // Community Management
    Route::get('/admin/community', [AdminCommunityController::class, 'index'])->name('admin.community');
    Route::post('/admin/community/post', [AdminCommunityController::class, 'postAsAdmin'])->name('admin.community.post');
    Route::post('/admin/community/posts/{post}/approve', [AdminCommunityController::class, 'approvePost'])->name('admin.community.approve');
    Route::post('/admin/community/posts/approve-all', [AdminCommunityController::class, 'approveAllPosts'])->name('admin.community.approve-all');
    Route::post('/admin/community/posts/{post}/reject', [AdminCommunityController::class, 'rejectPost'])->name('admin.community.reject');
    Route::delete('/admin/community/posts/{post}', [AdminCommunityController::class, 'deletePost'])->name('admin.community.delete');
    Route::post('/admin/community/comments/{comment}/approve', [AdminCommunityController::class, 'approveComment'])->name('admin.community.comment.approve');
    Route::post('/admin/community/comments/approve-all', [AdminCommunityController::class, 'approveAllComments'])->name('admin.community.comments.approve-all');
    Route::post('/admin/community/comments/{comment}/reject', [AdminCommunityController::class, 'rejectComment'])->name('admin.community.comment.reject');
    Route::post('/admin/community/settings', [AdminCommunityController::class, 'updateSettings'])->name('admin.community.settings');

    // Market News Management
    Route::get('/admin/news', [AdminNewsController::class, 'index'])->name('admin.news');
    Route::post('/admin/news', [AdminNewsController::class, 'store'])->name('admin.news.store');
    Route::put('/admin/news/{newsItem}', [AdminNewsController::class, 'update'])->name('admin.news.update');
    Route::delete('/admin/news/{newsItem}', [AdminNewsController::class, 'destroy'])->name('admin.news.destroy');
    Route::post('/admin/news/sync', [AdminNewsController::class, 'syncFromApi'])->name('admin.news.sync');

    // Real-time Chat (kept for API compatibility)
    Route::get('/admin/chat/token', [AdminChatController::class, 'getToken'])->name('admin.chat.token');

    // Unified Feed (Telegram-like)
    Route::get('/admin/feed', [AdminFeedController::class, 'index'])->name('admin.feed');
    Route::post('/admin/feed/post', [AdminFeedController::class, 'postAsAdmin'])->name('admin.feed.post');
    Route::post('/admin/feed/posts/{post}/approve', [AdminFeedController::class, 'approvePost'])->name('admin.feed.approve');
    Route::post('/admin/feed/posts/{post}/reject', [AdminFeedController::class, 'rejectPost'])->name('admin.feed.reject');
    Route::delete('/admin/feed/posts/{post}', [AdminFeedController::class, 'deletePost'])->name('admin.feed.delete');
    Route::post('/admin/feed/posts/{post}/pin', [AdminFeedController::class, 'togglePin'])->name('admin.feed.pin');
    Route::post('/admin/feed/comments/{comment}/approve', [AdminFeedController::class, 'approveComment'])->name('admin.feed.comment.approve');
    Route::post('/admin/feed/comments/{comment}/reject', [AdminFeedController::class, 'rejectComment'])->name('admin.feed.comment.reject');
    Route::post('/admin/feed/chat', [AdminFeedController::class, 'sendChat'])->name('admin.feed.chat');
    Route::post('/admin/feed/chat/{chat}/approve', [AdminFeedController::class, 'approveChat'])->name('admin.feed.chat.approve');
    Route::post('/admin/feed/chat/{chat}/reject', [AdminFeedController::class, 'rejectChat'])->name('admin.feed.chat.reject');
    Route::delete('/admin/feed/chat/{chat}', [AdminFeedController::class, 'deleteChat'])->name('admin.feed.chat.delete');
    Route::get('/admin/feed/pending-count', [AdminFeedController::class, 'getPendingCount'])->name('admin.feed.pending-count');
    Route::post('/admin/feed/settings', [AdminFeedController::class, 'updateSettings'])->name('admin.feed.settings');

    // Settings
    Route::post('/admin/settings', [SettingsController::class, 'update'])->name('admin.settings.update');

    // Database Backup
    Route::get('/admin/database-backup', [DatabaseBackupController::class, 'index'])->name('admin.db-backup');
    Route::get('/admin/database-backup/export', [DatabaseBackupController::class, 'export'])->name('admin.db-backup.export');
    Route::post('/admin/database-backup/import', [DatabaseBackupController::class, 'import'])->name('admin.db-backup.import');
    Route::get('/admin/database-backup/download/{filename}', [DatabaseBackupController::class, 'download'])->name('admin.db-backup.download');
    Route::delete('/admin/database-backup/delete/{filename}', [DatabaseBackupController::class, 'delete'])->name('admin.db-backup.delete');

    // Signal Reactions (admin view)
    Route::get('/admin/signals/{signal}/reactions', function ($signal) {
        $reactions = \App\Models\SignalReaction::where('signal_id', $signal)
            ->with('user:id,name,email')
            ->get()
            ->map(fn($r) => [
                'id' => $r->id,
                'emoji' => $r->emoji,
                'user_name' => $r->user->name ?? 'Unknown',
                'user_email' => $r->user->email ?? '',
                'created_at' => $r->created_at->diffForHumans(),
            ]);
        return response()->json($reactions);
    })->name('admin.signal.reactions');
});

require __DIR__.'/auth.php';
