<?php

namespace App\Http\Controllers;

use App\Models\Signal;
use App\Events\SignalCreated;
use App\Events\SignalUpdated;
use App\Events\SignalDeleted;
use Illuminate\Http\Request;

class SignalManageController extends Controller
{
    public function index()
    {
        $signals = Signal::latest('date')->paginate(20);

        return view('signals.index', compact('signals'));
    }

    public function create()
    {
        return view('signals.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'no' => 'required|integer',
            'date' => 'required|date',
            'pair' => 'required|string|max:20',
            'direction' => 'required|in,buy,sell',
            'entry1' => 'required|numeric',
            'entry2' => 'nullable|numeric',
            'sl' => 'required|numeric',
            'tp1' => 'required|numeric',
            'tp2' => 'nullable|numeric',
            'tp3' => 'nullable|numeric',
            'tp4' => 'nullable|numeric',
            'pips' => 'nullable|numeric',
            'profit' => 'nullable|numeric',
            'result' => 'required|in,win,loss,BE,pending',
            'channel' => 'nullable|string|max:100',
            'hit_level' => 'nullable|string|max:50',
            'status' => 'nullable|string|max:50',
        ]);

        $validated['user_id'] = $request->user()->id;

        $signal = Signal::create($validated);
        SignalCreated::dispatch($signal);

        return redirect()->route('admin.signals.index')->with('success', 'Signal created successfully.');
    }

    public function edit(Signal $signal)
    {
        return view('signals.edit', compact('signal'));
    }

    public function update(Request $request, Signal $signal)
    {
        $validated = $request->validate([
            'no' => 'required|integer',
            'date' => 'required|date',
            'pair' => 'required|string|max:20',
            'direction' => 'required|in,buy,sell',
            'entry1' => 'required|numeric',
            'entry2' => 'nullable|numeric',
            'sl' => 'required|numeric',
            'tp1' => 'required|numeric',
            'tp2' => 'nullable|numeric',
            'tp3' => 'nullable|numeric',
            'tp4' => 'nullable|numeric',
            'pips' => 'nullable|numeric',
            'profit' => 'nullable|numeric',
            'result' => 'required|in,win,loss,BE,pending',
            'channel' => 'nullable|string|max:100',
            'hit_level' => 'nullable|string|max:50',
            'status' => 'nullable|string|max:50',
        ]);

        $signal->update($validated);
        SignalUpdated::dispatch($signal, 'updated');

        return redirect()->route('admin.signals.index')->with('success', 'Signal updated successfully.');
    }

    public function destroy(Signal $signal)
    {
        SignalDeleted::dispatch($signal->id, $signal->no);
        $signal->delete();

        return redirect()->route('admin.signals.index')->with('success', 'Signal deleted successfully.');
    }
}
